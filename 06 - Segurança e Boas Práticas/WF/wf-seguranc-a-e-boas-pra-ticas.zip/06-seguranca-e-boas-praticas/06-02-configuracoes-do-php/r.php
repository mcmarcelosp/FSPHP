<?php
opcache_reset();